import sys

import sqlite3
from PIL import Image, ImageFilter
from PyQt5 import uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QFileDialog, QMainWindow
from PyQt5.QtGui import QIcon
import requests
from random import choice, randint


class MainScreen(QMainWindow):  # класс главного окна приложения
    def __init__(self):
        super().__init__()
        uic.loadUi('ALUB_design.ui', self)
        fname = QFileDialog.getOpenFileName(
            self, 'Выберете изображение (рек. 500х500):', '',
            'Картинка (*.jpg);;Картинка (*.jpg);;Все файлы (*)')[0]
        '''self.fname.move(300, 300)'''  # открытие окна проводника для выбора изображения
        self.start_image = fname  # исходник
        self.intermediate_img = 'intermediate.jpg'  # промежуточное изображение
        self.new_img = 'new.jpg'  # конечный результат
        if fname:
            img = Image.open(self.start_image)
            img.save(self.new_img)
            img.save(self.intermediate_img)
            self.pixmap = QPixmap(self.new_img)
            self.image.setPixmap(self.pixmap)
        else:
            sys.exit(1)
        self.initUI()

    def initUI(self):
        self.setWindowTitle('ALUB')
        self.setWindowIcon(QIcon('ALUB_logo.png'))  # логотип программы
        self.filter.adjustSize()
        self.rotate.adjustSize()
        self.sepia_label.adjustSize()
        self.adres.setText('Вставьте адрес изображения:')
        self.adres.adjustSize()
        self.pixmap = QPixmap(self.start_image)
        self.image.setPixmap(self.pixmap)
        self.open.clicked.connect(self.open_image)
        self.save.clicked.connect(self.save_image)
        self.save_as_b.clicked.connect(self.save_image_as)
        self.red.clicked.connect(self.r_color)
        self.rSlider.valueChanged.connect(self.change_r)
        self.green.clicked.connect(self.g_color)
        self.img_in_net.clicked.connect(self.search_image)
        self.gSlider_2.valueChanged.connect(self.change_g)
        self.blue.clicked.connect(self.b_color)
        self.bSlider_3.valueChanged.connect(self.change_b)
        self.sepia_slider.valueChanged.connect(self.sepia_f)
        self.all.clicked.connect(self.full_color)
        self.rotate_l.clicked.connect(self.l_turn)
        self.rotate_r.clicked.connect(self.r_turn)
        self.ng.clicked.connect(self.negativity)
        self.src.clicked.connect(self.average_color)
        self.bw.clicked.connect(self.black_and_white)
        self.modena_b.clicked.connect(self.modena_f)
        self.bgw.clicked.connect(self.bgw_f)
        self.rretro.clicked.connect(self.rretro_f)
        self.gretro.clicked.connect(self.gretro_f)
        self.sad_red_b.clicked.connect(self.sad_red)
        self.sad_green_b.clicked.connect(self.sad_green)
        self.sad_blue_b.clicked.connect(self.sad_blue)
        self.bw_center_b.clicked.connect(self.bw_center)
        self.full_bw.clicked.connect(self.only_black_and_white)
        self.three_D_b.clicked.connect(self.three_D)
        self.three_B_blue_b.clicked.connect(self.three_D_blue)
        self.saturation_b.clicked.connect(self.saturation)
        self.normal_rez.clicked.connect(self.sharpness)
        self.contur.clicked.connect(self.contur_f)
        self.black_b.clicked.connect(self.black_f)
        self.white_b.clicked.connect(self.white_f)
        self.Andy_Warhol_b.clicked.connect(self.Andy_Warhol)
        self.b_80.clicked.connect(self.f_80)
        self.random_b.clicked.connect(self.random_fs)
        self.bw_matrix_b.clicked.connect(self.bw_matrix_f)
        self.pushButton_4.clicked.connect(self.end_of_programm)
        self.three_D_green_b.clicked.connect(self.three_D_green)
        self.random_square_b.clicked.connect(self.random_square)
        self.filterSlider.valueChanged.connect(self.change_filter)
        self.one_h_sq_b.clicked.connect(self.one_hundred_squares_f)
        self.rotateSlider_2.valueChanged.connect(self.change_rotate)
        self.sakura_bw_center_b.clicked.connect(self.sakura_bw_center_f)
        self.random_nature_square_b.clicked.connect(self.random_nature_square)
        self.random_transparent_square_b.clicked.connect(self.random_transparent_square)
        self.im_ugol = 0  # коиф. поворота (используется в функциях, открывающих исходник

    def save_image(self):  # функция сохранения изображения
        new_img = Image.open(self.new_img)
        new_img.save('new.jpg')  # сохранение изображения (под именем "new.jpg" по умолчанию)
        self.save.setText('Сохраненно')

    def save_image_as(self):  # сохранить изображение как
        if self.save_as_name.text() and self.save_as_name.text()[-4:] == '.jpg':
            new_img = Image.open(self.new_img)
            new_img.save(self.save_as_name.text())
            self.save_as_b.setText('Сохраненно')
            self.actions_line.setText('Изображение удачно сохраненно.')
            self.actions_line.setStyleSheet('QLabel {color: green;}')
        elif self.save_as_name.text()[-4:] != '.jpg':
            self.actions_line.setText('Добавьте расширение .jpg, чтобы файл сохранился!')
            self.actions_line.setStyleSheet('QLabel {color: red;}')
        else:
            self.actions_line.setText('Вы не назвали свой файл!')
            self.actions_line.setStyleSheet('QLabel {color: red;}')

    def open_image(self):  # открытие изображения
        fname = QFileDialog.getOpenFileName(
            self, 'Выберете изображение (рек. 500х500):', '',
            'Картинка (*.jpg);;Картинка (*.jpg);;Все файлы (*)')[0]
        '''self.fname.move(300, 300)'''
        if fname:
            self.start_image = fname
            img = Image.open(self.start_image)
            img.save(self.new_img)
            img.save(self.intermediate_img)
            self.pixmap = QPixmap(self.start_image)
            self.image.setPixmap(self.pixmap)
            self.save.setText('Сохранить')
            self.save_as_b.setText('Сохранить как')
        else:
            self.start_image = self.start_image

    def random_fs(self):  # применение рандомных эффектов
        self.full_color()
        functions = (self.negativity, self.black_and_white, self.modena_f, self.bgw_f, self.rretro_f,
                     self.gretro_f, self.only_black_and_white, self.sharpness, self.contur_f,
                     self.black_f, self.white_f, self.sad_red, self.sad_blue, self.sad_green,
                     self.Andy_Warhol)  # кортеж с функциями эффектов
        for i in range(randint(1, 3)):
            a = randint(1, len(functions) - 1)
            functions[a]()
        self.actions_line.setText('RANDOM')

    def average_color(self):  # средний цвет изображения
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        a, u, c = 0, 0, 0
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                a += r
                u += g
                c += b
        red = a // (x * y)
        green = u // (x * y)
        blue = c // (x * y)
        color = red, green, blue
        for i in range(x):
            for j in range(y):
                pixels[i, j] = red, green, blue
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText(
            f'Применено усреднение цвета изображения. Цвет изображения равен: {str(color)}.')

    def negativity(self):  # негатив
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = 255 - r, 255 - g, 255 - b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен негатив.')

    def black_and_white(self):  # данная функция делает изобраение черно-белым
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = (r + g + b) // 3, (r + g + b) // 3, (r + g + b) // 3
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен черно-белый фильтр.')

    def modena_f(self):  # модена, фильтр инверсирующий синий
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, g, 255 - b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Модена".')

    def bgw_f(self):  # разделение цвета изображения по трем профилям: черный, белый и серый 130 оттенка
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                if (r + g + b) >= 400:
                    pixels[i, j] = 255, 255, 255
                elif (r + g + b) >= 200:
                    pixels[i, j] = 130, 130, 130
                else:
                    pixels[i, j] = 0, 0, 0
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText(
            'Применен "BGW" фильтр. Изображение состоит только из черного, белого и оп. серого цветов.')

    def rretro_f(self):  # инверсия синего, усление красного на 50 единиц и ослабление зеленого на тоже кол-во ед.
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                a, b, c = pixels[i, j][0], pixels[i, j][1], pixels[i, j][2]
                a += 50
                b -= 50
                c = 255 - c
                if a > 255:
                    a = 255
                if b > 255:
                    b = 255
                pixels[i, j] = a, b, c
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Ретро".')

    def gretro_f(self):  # инверсия синего, усление зеленого на 50 единиц и ослабление красного на тоже кол-во ед.
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                a, b, c = pixels[i, j][0], pixels[i, j][1], pixels[i, j][2]
                a -= 50
                b += 50
                c = 255 - c
                if a > 255:
                    a = 255
                if b > 255:
                    b = 255
                pixels[i, j] = a, b, c
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Неоновое Ретро".')

    def sad_red(self):  # замена зеленого профиля на синий (сам синий профиль ничем не заменяется)
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, b, b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Сакура".')

    def sad_green(self):  # замена красного профиля на синий (сам синий профиль ничем не заменяется)
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = b, g, b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Кислота".')

    def sad_blue(self):  # замена красного профиля на зеленый (сам зеленый профиль ничем не заменяется)
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = g, g, b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Синий Лимон".')

    def bw_center(self):  # часть изображния с координатами (125;125) размером 250х250 становится чб
        img = Image.open(self.new_img)
        pixels = img.load()
        for i in range(125, 375):
            for j in range(125, 375):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, r, r
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "ЧБ Центр".')

    def r_color(self):  # данная функция оставляет только красный профиль цветов
        img = Image.open(self.start_image)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, 0, 0
        img = img.rotate(self.im_ugol)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен красный фильтр.')

    def g_color(self):  # данная функция оставляет только зеленый профиль цветов
        img = Image.open(self.start_image)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = 0, g, 0
        img = img.rotate(self.im_ugol)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен зеленый фильтр.')

    def b_color(self):  # данная функция оставляет только синий профиль цветов
        img = Image.open(self.start_image)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = 0, 0, b
        img = img.rotate(self.im_ugol)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен синий фильтр.')

    def full_color(self):  # восстановление изображения, возвращение к исходнику
        img = Image.open(self.start_image)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, g, b
        self.im_ugol = 0
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setStyleSheet('QLabel {color: white;}')

    def three_D(self):  # классическая стереопара (по яндекс лицею) или 3D
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size

        for i in range(x - 1, 20 - 1, -1):
            for j in range(y):
                r = pixels[i - 20, j][0]
                R, g, b = pixels[i, j]
                pixels[i, j] = r, g, b
        for i in range(20):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = 0, g, b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен 3D эффект.')

    def three_D_blue(self):  # стереопара с синим и желтым
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x - 1, 20 - 1, -1):
            for j in range(y):
                b = pixels[i - 20, j][2]
                r, g, B = pixels[i, j]
                pixels[i, j] = r, g, b
        for i in range(20):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, g, 0
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен с/ж 3D эффект.')

    def three_D_green(self):  # стереопара с зеленым и розовым
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x - 1, 20 - 1, -1):
            for j in range(y):
                g = pixels[i - 20, j][1]
                r, G, b = pixels[i, j]
                pixels[i, j] = r, g, b
        for i in range(20):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, 0, b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен з/р 3D эффект.')

    def saturation(self):  # возводит в абсолют цвета после определенного занчения их цветового профиля
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                if r > g and r > b and r > 50:
                    r = 255
                elif g > r and g > b and g > 50:
                    g = 255
                elif b > r and b > g and b > 50:
                    b = 255
                elif g == b == r and (r + g + b) >= 300:
                    r, g, b = 255, 255, 255
                else:
                    r, g, b = 0, 0, 0
                pixels[i, j] = r, g, b
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен фильтр "Разбитый Экран".')

    def l_turn(self):  # поворот налево
        img = Image.open(self.new_img)
        img = img.rotate(90)
        self.im_ugol += 90
        self.im_ugol %= 360
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Поворот налево.')

    def r_turn(self):  # поворот направо
        img = Image.open(self.new_img)
        img = img.rotate(90)
        self.im_ugol -= 90
        self.im_ugol %= 360
        img = img.transpose(Image.ROTATE_180)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Поворот направо.')

    def change_rotate(self):  # поворот по слайдеру
        slider_value = int(self.rotateSlider_2.value())
        img = Image.open(self.intermediate_img)
        img = img.rotate(slider_value)
        img.save(self.new_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Точный поворот.')

    def change_r(self):  # изменение кол-ва красного по слайдеру
        slider_value = int(self.rSlider.value())
        self.im_curr = Image.open(self.intermediate_img)
        pixels = self.im_curr.load()
        x, y = self.im_curr.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = slider_value, g, b
        self.im_curr.save(self.new_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Смена кол-ва красного.')

    def change_g(self):  # изменение кол-ва зеленого по слайдеру
        slider_value = int(self.gSlider_2.value())
        self.im_curr = Image.open(self.intermediate_img)
        pixels = self.im_curr.load()
        x, y = self.im_curr.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, slider_value, b
        self.im_curr.save(self.new_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Смена кол-ва зеленого.')

    def change_b(self):  # изменение кол-ва синего по слайдеру
        slider_value = int(self.bSlider_3.value())
        self.im_curr = Image.open(self.intermediate_img)
        pixels = self.im_curr.load()
        x, y = self.im_curr.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, g, slider_value
        self.im_curr.save(self.new_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Смена кол-ва синего.')

    def change_filter(self):  # размытие по слайдеру
        slider_value = int(self.filterSlider.value())
        img = Image.open(self.intermediate_img)
        img = img.filter(ImageFilter.GaussianBlur(radius=slider_value))
        img.save(self.new_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Размытие.')

    def sepia_f(self):
        img = Image.open(self.intermediate_img)
        depth = int(self.sepia_slider.value())
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                a, b, c = pixels[i, j][0], pixels[i, j][1], pixels[i, j][2]
                coif = (a + b + c) // 3
                a = coif + depth * 2
                b = coif + depth
                c = coif
                if a > 255:
                    a = 255
                if b > 255:
                    b = 255
                if c > 255:
                    c = 255
                pixels[i, j] = a, b, c
        img.save(self.new_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен эффект "Сепия+".')

    def only_black_and_white(self):  # разделение цвета изображения по двум профилям: черный и белый
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                if (r + g + b) >= 400:
                    pixels[i, j] = 255, 255, 255
                else:
                    pixels[i, j] = 0, 0, 0
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText(
            'Применен фильтр "Абсолютное ЧБ". Изображение состоит только из черных и белых цветов.')

    def sharpness(self):  # резкость
        img = Image.open(self.new_img)
        img = img.filter(ImageFilter.SHARPEN)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применена Резкость.')

    def contur_f(self):  # контур
        img = Image.open(self.new_img)
        img = img.filter(ImageFilter.CONTOUR)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен эффект "Контур".')

    def black_f(self):  # баланс черного. т.е. перекрашиваем пиксель в  чистый черный, если сумма его r, g, b <= 50
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                if (r + g + b) <= 50:
                    pixels[i, j] = 0, 0, 0
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен баланс черного.')

    def white_f(self):  # баланс белого. т.е. перекрашиваем пиксель в  чистый белый, если сумма его r, g, b >= 700
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                if (r + g + b) >= 700:
                    pixels[i, j] = 255, 255, 255
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен баланс белого.')

    def Andy_Warhol(self):  # бежим по ох, пробегая случайную оy, окрашивая полученные пиксели в рандомные цвета
        img = Image.open(self.new_img)
        pixels = img.load()
        x, y = img.size
        for i in range(x):
            for j in range(randint(0, 500)):
                r, g, b = pixels[i, j]
                values = [r, g, b, randint(0, 255)]
                pixels[i, j] = choice(values), choice(values), choice(values)
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)
        self.actions_line.setText('Применен эффект "Информационный Шум".')

    def random_square(self):  # просто рандомный квадрат рандомного цвета
        img = Image.open(self.new_img)
        pixels = img.load()
        r, k = randint(0, 400), randint(0, 400)
        n_1, n_2 = randint(10, 100), randint(10, 100)  # randint(10, 200) хотелось бы'
        c = 0
        for i in range(r, r + n_1):
            for j in range(k, k + n_2):
                if i != r or j != k:
                    if c == 1:
                        r, g, b = pixels[i, j]
                        '''values = [r, g, b, 255, 0]'''
                        pixels[i, j] = value
                    else:
                        c += 1
                        r, g, b = pixels[i, j]
                        values = [r, g, b, 255, 0]
                        value = (choice(values), choice(values), choice(values))
                        self.actions_line.setText(
                            f'Применен эффект "Случайный Прямоугольник". Цвет прямоугольника: {str(value)}.')
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)

    def random_transparent_square(self):  # полупрозрачный рандомный квадрат
        img = Image.open(self.new_img)
        pixels = img.load()
        r, k = randint(0, 400), randint(0, 400)
        n_1, n_2 = randint(10, 100), randint(10, 100)  # randint(10, 200) хотелось бы'
        c = 0
        for i in range(r, r + n_1):
            for j in range(k, k + n_2):
                if i != r or j != k:
                    if c == 1:
                        r, g, b = pixels[i, j]
                        for a in range(2):
                            if value[a] != 0 and value[a] != 254:
                                value[a] = (r, g, b)[a]
                                pixels[i, j] = (value[0], value[1], value[2])
                    else:
                        c += 1
                        r, g, b = pixels[i, j]
                        values = [r, g, b, 254, 0]
                        value = [choice(values), choice(values), choice(values)]
                        pixels[i, j] = (value[0], value[1], value[2])
                        value_standart = (value[0], value[1], value[2])
                        self.actions_line.setText(
                            f'Применен эффект "Случайный Прозр. Прямоугольник". Цвет прямо-ка: {str(value_standart)}.')
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)

    def random_nature_square(self):  # рандомный квадрат, чей цвет зависит от случайного пикселя изображения
        img = Image.open(self.new_img)
        pixels = img.load()
        r, k = randint(0, 400), randint(0, 400)
        n_1, n_2 = randint(10, 100), randint(10, 100)  # randint(10, 200) хотелось бы'
        c = 0
        for i in range(r, r + n_1):
            for j in range(k, k + n_2):
                if i != r or j != k:
                    if c == 1:
                        r, g, b = pixels[i, j]
                        pixels[i, j] = value
                    else:
                        c += 1
                        r, g, b = pixels[i, j]
                        value = (r, g, b)
                        self.actions_line.setText(
                            f'Применен эффект "Случайный Натур. Прямоугольник". Цвет прямоугольника: {str(value)}.')
        img.save(self.new_img)
        img.save(self.intermediate_img)
        self.pixmap = QPixmap(self.new_img)
        self.image.setPixmap(self.pixmap)

    def sakura_bw_center_f(self):  # пресет "грустная сакура", вызывающий чб центер и сакуру (грустный красный)
        con = sqlite3.connect('sets.db')
        cur = con.cursor()
        result = cur.execute("""SELECT Sakura_bw_center FROM ALUB_sets""").fetchall()
        for a in result:
            for b in a:
                eval(b)()
        con.close()
        self.actions_line.setText('Применен пресет "Грустная Сакура".')

    def f_80(self):  # пресет "восьмидесятые", вызывающий модену и красное ретро
        con = sqlite3.connect('sets.db')
        cur = con.cursor()
        result = cur.execute("""SELECT s_80 FROM ALUB_sets""").fetchall()
        for a in result:
            for b in a:
                eval(b)()
        con.close()
        self.actions_line.setText('Применен пресет "Восьмидесятые".')

    def bw_matrix_f(self):  # пресет "чб матрица", делающий изображение чб и накладывающий инф. шум
        con = sqlite3.connect('sets.db')
        cur = con.cursor()
        result = cur.execute("""SELECT bw_matrix FROM ALUB_sets""").fetchall()
        for a in result:
            for b in a:
                eval(b)()
        con.close()
        self.actions_line.setText('Применен пресет "Черно-белая Матрица".')

    def one_hundred_squares_f(self):  # пресет, рисующий 100 случайных прямоугольников
        con = sqlite3.connect('sets.db')
        cur = con.cursor()
        result = cur.execute("""SELECT one_hundred_squares FROM ALUB_sets""").fetchall()
        for c in range(33):
            for a in result:
                for b in a:
                    eval(b)()
        con.close()
        self.actions_line.setText('Применен пресет "100 Прямоугольников".')

    def k(self):  # костыль для базы данных
        pass

    def end_of_programm(self):  # выход, конец программы
        sys.exit(1)

    def search_image(self):  # поиск и замена изображения с поиощью интернет-адреса
        url = self.url_line.text()
        if url:
            try:
                resp = requests.get(url, stream=True).raw
            except requests.exceptions.RequestException as e:
                self.adres.setText('Не существует!')
                self.adres.setStyleSheet('QLabel {color: red;}')
            img = Image.open(self.start_image)
            img.save('start_image_copy.jpg')

            if resp:
                try:
                    img = Image.open(resp)
                    self.adres.setStyleSheet('QLabel {color: white;}')
                    self.actions_line.setText('Вы удачно импортировали изображение из интернета!.')
                except IOError:
                    print("Невозможно открыть изображение!")
                    sys.exit(1)
                img.save(self.start_image)
                self.full_color()
                self.image.setPixmap(self.pixmap)
        else:
            self.adres.setText('Вы не ввели адрес!')
            self.adres.setStyleSheet('QLabel {color: red;}')
        pass


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainScreen()
    ex.show()
    sys.excepthook = except_hook
    sys.exit(app.exec())
